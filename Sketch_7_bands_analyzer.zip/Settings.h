/******************************************************************************************************************
*                                                                                                                 *
*  Project:  7 Band Spectrum Analyzer                                                                             *
*  Target Platform: Arduino NANO 328P Board                                                                       *
*  Version: 7.0                                                                                                   *
*                                                                                                                 *
*******************************************************************************************************************/

#pragma once
char version[]="7.0";                               // Define version number (NANO 7-BAR) for reference only

// Debugging
#define DEBUG_BUFFER_SIZE  50                       // Debug buffer size
int  DEBUG = 1;                                     // When debug=1, extra information is printed to serial port. 
                                                    // Turn of if not needed--> DEBUG=0
// Ledstrips/ matrix main display  *********************************************************************************
#define LED_PIN           2                         // This is the data pin of your led matrix, or ledstrips.
#define COLUMNS           7                         // Number of bands on display, this is not the same as display width,
                                                    // because display can be 28 ( double pixels per bar)
//const uint8_t                                     // if you have more then 16 bands, you will need to change the Led Matrix Arrays in the main file.
#define kMatrixWidth      7                         // Matrix width --> number of columns in your led matrix
#define kMatrixHeight    20                         // Matrix height --> number of leds per column   

// Some definitions for setting up the matrix  **************************************************************************
#define BAR_WIDTH  (kMatrixWidth / (COLUMNS -1))    // If width >= 8 light 1 LED width per bar, >= 16 light 2 LEDs width bar etc
#define TOP        (kMatrixHeight - 0)              // Don't allow the bars to go offscreen
#define NUM_LEDS   (kMatrixWidth * kMatrixHeight)   // Total number of LEDs in the display array

// Ledstrips or pixelmatrix  ********************************************************************************************
#define CHIPSET      WS2812B                        // LED strip type -> Same for both ledstrip outputs( Matrix and logo)
#define BRIGHTNESSMAX    150                        // Max brightness of the leds...carefull...to bright might draw to much amps!
#define COLOR_ORDER      GRB                        // If colours look wrong, play with this
#define LED_VOLTS          5                        // Usually 5 or 12
#define MAX_MILLIAMPS   2000                        // Careful with the amount of power here if running off USB port, This will effect your brightnessmax. Currentlimit overrules it.
                                                    // If your power supply or usb can not handle the set current, arduino will freeze due to power drops.
// ADC Filter  **********************************************************************************************************
#define NOISE             20                        // Used as a crude noise filter on the adc input, values below this are ignored

//Controls  *************************************************************************************************************
#define PEAKDELAYPOT      A3                        // Potmeter for sensitivity input 0...5V (0-3.3V on ESP32)
#define SENSITIVITYPOT    A2                        // Potmeter for Brightness input 0...5V (0-3.3V on ESP32)  
#define BRIGHTNESSPOT     A1                        // Potmeter for Peak Delay Time input 0...5V (0-3.3V on ESP32)
#define Switch1           A0                        // Connect a push button to this pin to change patterns PIN64
#define LONG_PRESS_MS   3000                        // Number of ms to count as a long press on the switch

// MSGEQ7 Pinout Connections  *******************************************************************************************
#define RESET_PIN         7                         //MSGEQ7 reset pin
#define STROBE_PIN        8                         //MSGEQ7 strobe pin

int BRIGHTNESSMARK =    100;                        // Default brightnetss, however, overruled by the Brightness potmeter
int AMPLITUDE      =   2000;                        // Depending on your audio source level, you may need to alter this value. it's controlled by the Sensitivity Potmeter

// Peak related stuff  **************************************************************************************************
#define Fallingspeed     20                         // This is the time it takes for peak tiels to fall to stack, this is not the extra time that you can add by using the potmeter
                                                    // for peakdelay. Because that is the extra time it levitates before falling to the stack    
#define AutoChangetime   10                         // If the time  in seconds between modes, when the patterns change automatically, if to fast, you can increase this number            
#define NumberOfModes    17                         // The number of modes, remember it starts counting at 0,so if your last mode is 11 then the total number of modes is 12
#define DefaultMode       1                         // This is the mode it will start with after a reset or boot
#define DemoAfterSec   6000                         // if there is no input signal during this number of seconds, the unit will go to demo mode
#define DemoTreshold     10                         // this defines the treshold that will get the unit out of demo mode

CRGB leds[NUM_LEDS];                                // Leds on the Ledstrips/Matrix of the actual Spectrum analyzer lights.

/*****************************************************************^^^^^***********
 * Colors of bars and peaks in different modes, changeable to your likings       *
 ************************************************************************^^^^****/

// Static horizontal Rainbow ************************************************************************
#define RainbowBars_Color  (x / BAR_WIDTH) * (255 / COLUMNS), 255, 255

// Dynamic Horizontal Rainbow ***********************************************************************
#define RainbowBars_Color1  (x / BAR_WIDTH) * (255 / COLUMNS) + colorTimer, 255, 255

// Dynamic Vertical Rainbow *************************************************************************
#define ChangingBars_Color   y * (255 / kMatrixHeight) + colorTimer, 255, 255

// ***************************** YouTub Gradient Color Modes ***************************
DEFINE_GRADIENT_PALETTE( youtub1_gp ) {
  0, 255,   0,   0,  
 35, 255,   0,   0,
100,   0, 255,   0,
170,   0,   0, 200,
255, 255,   0, 255, };
CRGBPalette16 youtub1 = youtub1_gp;

DEFINE_GRADIENT_PALETTE( youtub2_gp ) {
  0,   0, 255, 255,  
 29,   0, 255, 255,
 30,   0, 255,   0, 
 80,   0, 255,   0,
100, 255, 110, 210,
200, 200,   5,   5,
255, 255,   0,   0, }; 
CRGBPalette16 youtub2 = youtub2_gp;

DEFINE_GRADIENT_PALETTE( youtub3_gp ) {
  0, 157,   0, 255,  
 30, 255,   0, 157,
 40, 255, 100,   0, 
 90, 255, 200,   0,
120, 100, 255, 255,
200,   5, 255,   5,
255,   0, 255,   0, }; 
CRGBPalette16 youtub3 = youtub3_gp;

DEFINE_GRADIENT_PALETTE( youtub4_gp ) {
  0,   0, 255,   0,  
 35,   0, 255,   0,
 90, 100, 255, 255,
130, 255, 100, 255,
160, 255,  10, 100,
190, 255,  15,   5,
255, 255,  10,   0, }; 
CRGBPalette16 youtub4 = youtub4_gp;

DEFINE_GRADIENT_PALETTE( youtub5_gp ) {
  0, 255,   0,   0,  
 50, 255,   0,  20,
110, 255, 255, 255,
130,  50, 255, 255,
160,   0, 150, 255,
190,   5,  15, 255,
255,   0,  10, 255, }; 
CRGBPalette16 youtub5 = youtub5_gp;

DEFINE_GRADIENT_PALETTE( youtub6_gp ) {  
  0,   0,   0, 255,  
 20,   0,   0, 255,
 80,  55,   0, 255,
120, 255,  60,   0,
210,   0, 255,  20,
255,   0, 255,   0, }; 
CRGBPalette16 youtub6 = youtub6_gp;

DEFINE_GRADIENT_PALETTE( youtub7_gp ) {
  0,   200, 200,  200,   //White
 64,   255, 218,    0,   //Green
128,   231,   0,    0,   //Red
192,   255, 218,    0,   //Green
255,   200, 200,  200 }; //White
CRGBPalette16 youtub7 = youtub7_gp;


// ADDITIONAL PEAK COLOR MODES  ***************************************************
int PeakD = 255;

#define Peak_Red            255,   5,   0           // Red peaks
#define Peak_Blue             5,   0, 255           // Blue peaks
#define Peak_Green            5, 225,   0           // Green peaks
#define Peak_Orange         215,   5,   0           // Orange peaks
#define Peak_Purple         235,   5,  95           // Purple peaks
#define Peak_Pink           255,   5,  42           // Blue peaks
#define Peak_Violet         150,   5, 215           // Magenta peaks
#define Peak_Cyan             0, 155, 235           // Purple peaks

// ******************************* T H E  E N D ************************************
